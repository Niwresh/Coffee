<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Login</title>
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="Desktop1" style="width: 1440px; height: 1024px; position: relative; background: linear-gradient(180deg, #985110 100%, rgba(134.58, 78.30, 26.36, 0) 100%); box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25); backdrop-filter: blur(50px)">
                            <div class="Rectangle1" style="width: 1159px; height: 746px; left: 161px; top: 156px; position: absolute; background: rgba(46.40, 32.02, 18.75, 0.63); border-radius: 50px"></div>
                            <div class="EmailPhone" style="left: 826px; top: 344px; position: absolute; color: white; font-size: 20px; font-family: Poppins; font-weight: 400; word-wrap: break-word">Email/phone:</div>
                            <img class="Rectangle9" style="width: 50px; height: 50px; left: 1065px; top: 693px; position: absolute" src="image/download (1).png" />
                            <img class="Rectangle8" style="width: 50px; height: 50px; left: 951px; top: 693px; position: absolute" src="image/download.png" />
                            <div class="RememberMe" style="left: 878px; top: 538px; position: absolute"><span style="color: white; font-size: 20px; font-family: Inter; font-weight: 600; word-wrap: break-word">Remember m</span><span style="color: white; font-size: 20px; font-family: Poppins; font-weight: 600; word-wrap: break-word">e</span></div>
                            <div class="Login" style="left: 961px; top: 275px; position: absolute; color: white; font-size: 50px; font-family: Poppins; font-weight: 600; word-wrap: break-word">LOGIN</div>
                            
                            <img class="Rectangle2" style="width: 601px; height: 746px; left: 161px; top: 156px; position: absolute; border-radius: 30px" src="image/circles brown.jpg" />
                            <div class="Rectangle5" style="width: 33px; height: 25px; left: 830px; top: 543px; position: absolute; background: #D9D9D9"></div>
                            <div class="ForgetPassword" style="left: 1067px; top: 539px; position: absolute; color: white; font-size: 20px; font-family: Poppins; font-weight: 600; word-wrap: break-word">Forget Password?</div>
                            
                            <div class="Frame" style="width: 38px; height: 24px; left: 1032px; top: 624px; position: absolute"></div>

                            <div class="Or" style="left: 1014px; top: 657px; position: absolute; color: #F5F5F5; font-size: 24px; font-family: Poppins; font-weight: 600; word-wrap: break-word">OR</div>

                            <div class="Password" style="left: 828px; top: 440px; position: absolute; color: white; font-size: 20px; font-family: Poppins; font-weight: 400; word-wrap: break-word">Password:</div>
                            <div class="Ellipse8" style="width: 174px; height: 162px; left: 98px; top: 797px; position: absolute; background: linear-gradient(180deg, rgba(227.81, 156.34, 90.37, 0.54) 37%, rgba(234.46, 169.44, 109.41, 0.86) 58%, rgba(216.40, 133.88, 57.71, 0) 100%); border-radius: 9999px"></div>
                            <div class="Ellipse6" style="width: 152px; height: 136px; left: 479px; top: 123px; position: absolute; background: linear-gradient(180deg, rgba(234.46, 169.44, 109.41, 0.86) 24%, rgba(227.81, 156.34, 90.37, 0.54) 86%, rgba(216.40, 133.88, 57.71, 0) 100%); border-radius: 9999px"></div>
                            <div class="Ellipse12" style="width: 149px; height: 147px; left: 631px; top: 797px; position: absolute; background: linear-gradient(180deg, rgba(234.46, 169.44, 109.41, 0.86) 24%, rgba(227.81, 156.34, 90.37, 0.54) 86%, rgba(216.40, 133.88, 57.71, 0) 100%); border-radius: 9999px"></div>
                            <div class="Ellipse3" style="width: 149px; height: 144px; left: 613px; top: 66px; position: absolute; background: linear-gradient(180deg, rgba(234.46, 169.44, 109.41, 0.86) 24%, rgba(227.81, 156.34, 90.37, 0.54) 28%, rgba(216.40, 133.88, 57.71, 0) 100%); border-radius: 9999px"></div>
                            <div class="Ellipse4" style="width: 174px; height: 137px; left: 109px; top: 108px; position: absolute; background: linear-gradient(180deg, rgba(234.46, 169.44, 109.41, 0.86) 24%, rgba(227.81, 156.34, 90.37, 0.54) 37%, rgba(216.40, 133.88, 57.71, 0) 100%); border-radius: 9999px"></div>
                            <div class="Ellipse9" style="width: 163px; height: 143px; left: 109px; top: 475px; position: absolute; background: linear-gradient(180deg, rgba(234.46, 169.44, 109.41, 0.86) 24%, rgba(227.81, 156.34, 90.37, 0.54) 37%, rgba(216.40, 133.88, 57.71, 0) 100%); border-radius: 9999px"></div>
                            <div class="Rectangle10" style="width: 400px; height: 473px; left: 263px; top: 285px; position: absolute; mix-blend-mode: multiply; background: linear-gradient(180deg, #E9E1DA 100%, rgba(234.46, 169.44, 109.41, 0) 100%); box-shadow: 10px 10px 10px; filter: blur(10px)"></div>
                            <img class="Ellipse11" style="width: 486px; height: 449px; left: 220px; top: 259px; position: absolute; border-radius: 9999px" src="image/decs.png" />
                            <div class="ThePerfectBlend" style="width: 346px; height: 34px; left: 306px; top: 657px; position: absolute; color: black; font-size: 32px; font-family: Poppins; font-weight: 500; text-decoration: underline; word-wrap: break-word">THE PERFECT BLEND</div>
                            <img class="Ellipse13" style="width: 129px; height: 104px; left: 973px; top: 181px; position: absolute; border-radius: 9999px" src="image/d.jpg" />
                            <img class="Ellipse14" style="width: 55px; height: 44px; left: 835px; top: 387px; position: absolute; border-radius: 9999px" src="https://via.placeholder.com/55x44" />
                            <img class="Rectangle11" style="width: 44px; height: 37px; left: 841px; top: 479px; position: absolute" src="https://via.placeholder.com/44x37" />
                          </div>
        


        <div class="form-floating mb-3" style="width: 427px; height: 48px; left: 830px; top: -650px; background: #D9D9D9; border-radius: 20px">
            <input class="form-control"  id="inputEmail" type="email" placeholder="name@example.com" />
            <label for="inputEmail">Email address</label>
        </div>

        <div class="form-floating mb-3" style="width: 427px; height: 48px; left: 950px; top: 474px; position: absolute; background: #D9D9D9; border-radius: 20px" >
            <input class="form-control" id="inputPassword" type="password" placeholder="Password" />
            <label for="inputPassword">Password</label>
        </div>

        <div class="mt-4 mb-0" >
            <a class="btn btn-primary"  style="width: 427px; height: 48px; left: 950px; top: 600px; position: absolute; background: rgba(216.40, 133.88, 57.71, 0.86); border-radius: 240px" href="index.php">LOGIN</a>
        </div>

        <div class="card-footer text-center py-3">
            <a class="btn btn-primary"  style="width: 427px; height: 48px; left: 950px; top: 760px; position: absolute; background: rgba(216.40, 133.88, 57.71, 0.86); border-radius: 240px" href="register.php">REGISTER</a>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
