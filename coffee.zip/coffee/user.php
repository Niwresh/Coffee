<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>USER LIST</title>
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        
                        <div class="Desktop1" style="width: 1440px; height: 1024px; position: relative; background: #985110">
                            <div class="Rectangle1" style="width: 424px; height: 57px; left: 940px; top: 29px; position: absolute; background: linear-gradient(180deg, #8F8383 0%, rgba(255, 255, 255, 0) 100%); border-radius: 20px; border: 3px white solid"></div>
                            <div class="Frame" style="width: 41px; height: 41px; left: 954px; top: 35px; position: absolute">
                              <div class="Vector" style="width: 32.37px; height: 37.50px; left: 6.83px; top: 1.71px; position: absolute; background: white"></div>
                            </div>
                            <img class="Ellipse1" style="width: 1440px; height: 1024px; left: 0px; top: 0px; position: absolute; border-radius: 9999px" src="https://via.placeholder.com/1440x1024" />
                            <div class="Users" style="left: 145px; top: 153px; position: absolute; color: white; font-size: 36px; font-family: Poppins; font-weight: 600; word-wrap: break-word">Users:</div>
                            <div class="Frame" style="width: 41px; height: 40px; left: 96px; top: 158px; position: absolute">
                              <div class="Vector" style="width: 27.33px; height: 35px; left: 6.83px; top: 1.67px; position: absolute; background: white"></div>
                            </div>
                            <div class="Line1" style="width: 1263px; height: 0px; left: 93px; top: 214px; position: absolute; border: 5px white solid"></div>
                            <div class="Rectangle2" style="width: 1286px; height: 723px; left: 78px; top: 235px; position: absolute; opacity: 0.60; background: linear-gradient(180deg, #D9D9D9 39%, rgba(217, 217, 217, 0) 100%); border-radius: 15px; border: 8px white solid"></div>
                            <div class="Rectangle3" style="width: 244px; height: 47px; left: 96px; top: 269px; position: absolute; background: white; border-radius: 20px; border: 3px #985110 solid"></div>
                            <div class="Frame" style="width: 24px; height: 24px; left: 125px; top: 280px; position: absolute">
                              <div class="Vector" style="width: 19px; height: 21px; left: 4px; top: 1px; position: absolute; background: black"></div>
                            </div>
                            <div class="Rectangle6" style="width: 244px; height: 47px; left: 873px; top: 269px; position: absolute; background: white; border-radius: 20px; border: 3px #985110 solid"></div>
                            <div class="Role" style="left: 965px; top: 279px; position: absolute; color: black; font-size: 24px; font-family: Ponnala; font-weight: 400; word-wrap: break-word">ROLE</div>
                            <div class="Rectangle7" style="width: 207px; height: 47px; left: 1132px; top: 269px; position: absolute; background: white; border-radius: 20px; border: 3px #985110 solid"></div>
                            <div class="Action" style="left: 1191px; top: 278px; position: absolute; color: black; font-size: 24px; font-family: Ponnala; font-weight: 400; word-wrap: break-word">ACTION</div>
                            <div class="Rectangle5" style="width: 244px; height: 47px; left: 614px; top: 269px; position: absolute; background: white; border-radius: 20px; border: 3px #954F0E solid"></div>
                            <div class="Frame" style="width: 24px; height: 24px; left: 640px; top: 280px; position: absolute">
                              <div class="Vector" style="width: 20px; height: 20px; left: 2px; top: 1px; position: absolute; background: black"></div>
                            </div>
                            <div class="TimeStamp" style="left: 681px; top: 280px; position: absolute; color: black; font-size: 22px; font-family: Ponnala; font-weight: 400; word-wrap: break-word">TIME STAMP</div>
                            <div class="Rectangle4" style="width: 244px; height: 47px; left: 355px; top: 269px; position: absolute; background: white; border-radius: 20px; border: 3px #985110 solid"></div>
                            <div class="Frame" style="width: 24px; height: 24px; left: 422px; top: 280px; position: absolute">
                              <div class="Vector" style="width: 22px; height: 20px; left: 2px; top: 3px; position: absolute; background: black"></div>
                            </div>
                            <div class="Email" style="left: 453px; top: 279px; position: absolute; color: black; font-size: 24px; font-family: Ponnala; font-weight: 400; word-wrap: break-word">EMAIL</div>
                            <div class="Search" style="left: 1003px; top: 42px; position: absolute; color: white; font-size: 28px; font-family: Ponnala; font-weight: 400; word-wrap: break-word">Search....</div>
                            <div class="Fullname" style="left: 156px; top: 277px; position: absolute; color: black; font-size: 24px; font-family: Ponnala; font-weight: 400; word-wrap: break-word">FULLNAME</div>
                            <div class="Line2" style="width: 1243.01px; height: 0px; left: 96px; top: 379px; position: absolute; border: 5px #985110 solid"></div>
                            <div class="Line9" style="width: 1251.01px; height: 0px; left: 93px; top: 895.96px; position: absolute; border: 5px #954F0E solid"></div>
                            <div class="Line3" style="width: 1243px; height: 0px; left: 96px; top: 452px; position: absolute; border: 5px #954F0E solid"></div>
                            <div class="Line8" style="width: 1243px; height: 0px; left: 96px; top: 825.03px; position: absolute; border: 5px #954F0E solid"></div>
                            <div class="Line6" style="width: 1246.01px; height: 0px; left: 93px; top: 676px; position: absolute; border: 5px #954F0E solid"></div>
                            <div class="Line7" style="width: 1246.01px; height: 0px; left: 93px; top: 755px; position: absolute; border: 5px #954F0E solid"></div>
                            <div class="Line5" style="width: 1246px; height: 0px; left: 93px; top: 597px; position: absolute; border: 5px #954F0E solid"></div>
                            <div class="Line4" style="width: 1243.04px; height: 0px; left: 98px; top: 524px; position: absolute; border: 5px #985110 solid"></div>
                            <div class="Admin" style="width: 215px; left: 148px; top: 89px; position: absolute; color: white; font-size: 50px; font-family: Red Rose; font-weight: 400; word-wrap: break-word">ADMIN</div>
                            <div class="Frame" style="width: 53px; height: 33px; left: 90px; top: 103px; position: absolute">
                              <div class="Vector" style="width: 39.75px; height: 28.88px; left: 8.83px; top: 1.38px; position: absolute; background: white"></div>
                            </div>
                            <div class="Frame" style="width: 41px; height: 40px; left: 1091px; top: 153px; position: absolute">
                              <div class="Vector" style="width: 31.43px; height: 35.83px; left: 6.83px; top: 1.67px; position: absolute; background: white"></div>
                            </div>
                            <div class="UserSetting" style="left: 1138px; top: 151px; position: absolute; color: white; font-size: 34px; font-family: Poppins; font-weight: 600; word-wrap: break-word">User-setting</div>
                            <div class="Frame" style="width: 51px; height: 52px; left: 1376px; top: 31px; position: absolute">
                              <div class="Vector" style="width: 38.25px; height: 36.83px; left: 6.38px; top: 7.58px; position: absolute; background: white"></div>
                            </div>
                            <div class="Frame" style="width: 24px; height: 24px; left: 1158px; top: 280px; position: absolute">
                              <div class="Vector" style="width: 19px; height: 22px; left: 4px; top: 1px; position: absolute; background: black"></div>
                            </div>
                          </div>


            </div>
            <!---<div class="form-floating mb-3 mb-md-0">---->
                <input class="form-control"   style="width: 313px; height: 62px; left: 355px; top: 157px; position: absolute; background: white; border-radius: 30px; border: 5px #954F0E solid" id="inputFirstName" type="text" placeholder="Enter your First Name" />
                <label for="inputFirstName"></label>
            </div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control"   style="width: 313px; height: 62px; left: 685px; top: 157px; position: absolute; background: white; border-radius: 30px; border: 5px #954F0E solid" id="ENTER MIDDLE NAME" type="text" placeholder="Enter your Middle Name" />
    <label for="ENTER MIDDLE NAME"></label>
</div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control"   style="width: 313px; height: 62px; left: 1015px; top: 157px; position: absolute; background: white; border-radius: 30px; border: 5px #954F0E solid" id="ENTER LAST NAME" type="text" placeholder="Enter your Last Name" />
    <label for="ENTER LAST NAME"></label>
</div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control"   style="width: 276px; height: 61px; left: 375px; top: 255px; position: absolute; background: white; border: 5px #985110 solid" id="ENTER PHONE NUMBER" type="text" placeholder="Enter your Phone Number" />
    <label for="ENTER PHONE NUMBER"></label>
</div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control"  style="width: 276px; height: 61px; left: 710px; top: 255px; position: absolute; background: white; border: 5px #954F0E solid" id="HOUSE NUMBER" type="text" placeholder="Enter your House Number" />
    <label for="ENTER HOUSE NUMBER"></label>
</div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control"  style="width: 260px; height: 61px; left: 1030px; top: 255px; position: absolute; background: white; border: 5px #985110 solid" id="STREET" type="text" placeholder="Enter your Street Number" />
    <label for="ENTER STREET"></label>
</div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control"  style="width: 276px; height: 61px; left: 375px; top: 358px; position: absolute; background: white; border: 5px #954F0E solid" id="BARANGAY" type="text" placeholder="Enter your Barangay" />
    <label for="ENTER BARANGAY"></label>
</div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control"  style="width: 276px; height: 61px; left: 710px; top: 358px; position: absolute; background: white; border: 5px #954F0E solid" id="MUNICIPALITY" type="text" placeholder="Enter your Municipality/City" />
    <label for="ENTER MUNICIPALITY/CITY"></label>
</div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control"  style="width: 276px; height: 61px; left: 1030px; top: 358px; position: absolute; background: white; border: 5px #954F0E solid" id="PROVINCE" type="text" placeholder="Enter your Province" />
    <label for="ENTER PROVINCE"></label>
</div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control"  style="width: 276px; height: 61px; left: 710px; top: 456px; position: absolute; background: white; border: 5px #954F0E solid" id="ZIPCODE" type="text" placeholder="Enter your Zipcode" />
    <label for="ENTER ZIPCODE"></label>
</div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control" style="width: 812px; height: 61px; left: 450px; top: 564px; position: absolute; background: white; border: 5px #954F0E solid" id="EMAIL" type="text" placeholder="Enter your Email" />
    <label for="ENTER EMAIL"></label>
</div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control" style="width: 812px; height: 61px; left: 450px; top: 678px; position: absolute; background: white; border: 5px #954F0E solid" id="PASS" type="password" placeholder="Enter your Password" />
    <label for="ENTER PASSWORD"></label>
</div>

<div class="card-footer text-center py-3">
    <a class="btn" style="width: 402px; height: 67px; left: 650px; top: 816px; position: absolute; background: #976739; border-radius: 30px; border: 5px white solid color: white; font-size: 36px; font-family: Poppins; font-weight: 600; word-wrap: break-word" href="login.php">REGISTER</a>
</div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>

                    