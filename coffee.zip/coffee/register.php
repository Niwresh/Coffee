<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Register</title>
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="Desktop1" style="width: 1440px; height: 1024px; position: relative; background: #954F0E">
                            <img class="Ellipse1" style="width: 1440px; height: 1000px; left: 0px; top: 0px; position: absolute; border-radius: 9999px" src="image/decs.png" />
                            <div class="Rectangle2" style="width: 1191px; height: 759px; left: 140px; top: 91px; position: absolute; opacity: 0.60; background: linear-gradient(180deg, #D9D9D9 8%, #D9D9D9 36%, rgba(217, 217, 217, 0) 100%); border-radius: 20px; border: 8px white solid"></div>
                            <div class="Zipcode" style="left: 660px; top: 423px; position: absolute; color: black; font-size: 24px; font-family: Poppins; font-weight: 500; word-wrap: break-word">ZIPCODE:</div>
                            <div class="PhoneNumber" style="left: 300px; top: 219px; position: absolute; color: black; font-size: 24px; font-family: Poppins; font-weight: 500; word-wrap: break-word">PHONE NUMBER:</div>
                            <div class="MunicipalityCity" style="left: 620px; top: 320px; position: absolute; color: black; font-size: 24px; font-family: Poppins; font-weight: 500; word-wrap: break-word">MUNICIPALITY/CITY</div>
                            <div class="HouseNo" style="left: 660px; top: 219px; position: absolute; color: black; font-size: 24px; font-family: Poppins; font-weight: 500; word-wrap: break-word">HOUSE NO:</div>
                            <div class="Barangay" style="left: 315px; top: 322px; position: absolute; color: black; font-size: 24px; font-family: Poppins; font-weight: 500; word-wrap: break-word">BARANGAY:</div>
                            <div class="Street" style="left: 990px; top: 219px; position: absolute; color: black; font-size: 24px; font-family: Poppins; font-weight: 500; word-wrap: break-word">STREET:</div>
                            <div class="MiddleName" style="left: 637px; top: 119px; position: absolute; color: black; font-size: 24px; font-family: Poppins; font-weight: 500; word-wrap: break-word">MIDDLE NAME:</div>
                            <div class="LastName" style="left: 991px; top: 119px; position: absolute; color: black; font-size: 24px; font-family: Poppins; font-weight: 500; word-wrap: break-word">LAST NAME:</div>
                            <div class="FirstName" style="left: 306px; top: 117px; position: absolute; color: black; font-size: 24px; font-family: Poppins; font-weight: 500; word-wrap: break-word">FIRST NAME:</div>
                            <div class="Province" style="left: 991px; top: 320px; position: absolute; color: black; font-size: 24px; font-family: Poppins; font-weight: 500; word-wrap: break-word">PROVINCE:</div>
                            <div class="Email" style="left: 350px; top: 527px; position: absolute; color: black; font-size: 24px; font-family: Poppins; font-weight: 500; word-wrap: break-word">EMAIL:</div>
                            <div class="Password" style="left: 350px; top: 642px; position: absolute; color: black; font-size: 24px; font-family: Poppins; font-weight: 500; word-wrap: break-word">PASSWORD:</div>
                            <div class="Register" style="left: 633px; top: 816px; position: absolute; color: white; font-size: 36px; font-family: Poppins; font-weight: 600; word-wrap: break-word">REGISTER</div>
                          </div>
            </div>
            <!---<div class="form-floating mb-3 mb-md-0">---->
                <input class="form-control"   style="width: 313px; height: 62px; left: 355px; top: 157px; position: absolute; background: white; border-radius: 30px; border: 5px #954F0E solid" id="inputFirstName" type="text" placeholder="Enter your First Name" />
                <label for="inputFirstName"></label>
            </div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control"   style="width: 313px; height: 62px; left: 685px; top: 157px; position: absolute; background: white; border-radius: 30px; border: 5px #954F0E solid" id="ENTER MIDDLE NAME" type="text" placeholder="Enter your Middle Name" />
    <label for="ENTER MIDDLE NAME"></label>
</div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control"   style="width: 313px; height: 62px; left: 1015px; top: 157px; position: absolute; background: white; border-radius: 30px; border: 5px #954F0E solid" id="ENTER LAST NAME" type="text" placeholder="Enter your Last Name" />
    <label for="ENTER LAST NAME"></label>
</div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control"   style="width: 276px; height: 61px; left: 375px; top: 255px; position: absolute; background: white; border: 5px #985110 solid" id="ENTER PHONE NUMBER" type="text" placeholder="Enter your Phone Number" />
    <label for="ENTER PHONE NUMBER"></label>
</div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control"  style="width: 276px; height: 61px; left: 710px; top: 255px; position: absolute; background: white; border: 5px #954F0E solid" id="HOUSE NUMBER" type="text" placeholder="Enter your House Number" />
    <label for="ENTER HOUSE NUMBER"></label>
</div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control"  style="width: 260px; height: 61px; left: 1030px; top: 255px; position: absolute; background: white; border: 5px #985110 solid" id="STREET" type="text" placeholder="Enter your Street Number" />
    <label for="ENTER STREET"></label>
</div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control"  style="width: 276px; height: 61px; left: 375px; top: 358px; position: absolute; background: white; border: 5px #954F0E solid" id="BARANGAY" type="text" placeholder="Enter your Barangay" />
    <label for="ENTER BARANGAY"></label>
</div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control"  style="width: 276px; height: 61px; left: 710px; top: 358px; position: absolute; background: white; border: 5px #954F0E solid" id="MUNICIPALITY" type="text" placeholder="Enter your Municipality/City" />
    <label for="ENTER MUNICIPALITY/CITY"></label>
</div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control"  style="width: 276px; height: 61px; left: 1030px; top: 358px; position: absolute; background: white; border: 5px #954F0E solid" id="PROVINCE" type="text" placeholder="Enter your Province" />
    <label for="ENTER PROVINCE"></label>
</div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control"  style="width: 276px; height: 61px; left: 710px; top: 456px; position: absolute; background: white; border: 5px #954F0E solid" id="ZIPCODE" type="text" placeholder="Enter your Zipcode" />
    <label for="ENTER ZIPCODE"></label>
</div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control" style="width: 812px; height: 61px; left: 450px; top: 564px; position: absolute; background: white; border: 5px #954F0E solid" id="EMAIL" type="text" placeholder="Enter your Email" />
    <label for="ENTER EMAIL"></label>
</div>

<!---<div class="form-floating mb-3 mb-md-0">---->
    <input class="form-control" style="width: 812px; height: 61px; left: 450px; top: 678px; position: absolute; background: white; border: 5px #954F0E solid" id="PASS" type="password" placeholder="Enter your Password" />
    <label for="ENTER PASSWORD"></label>
</div>

<div class="card-footer text-center py-3">
    <a class="btn" style="width: 402px; height: 67px; left: 650px; top: 816px; position: absolute; background: #976739; border-radius: 30px; border: 5px white solid color: white; font-size: 36px; font-family: Poppins; font-weight: 600; word-wrap: break-word" href="login.php">REGISTER</a>
</div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
